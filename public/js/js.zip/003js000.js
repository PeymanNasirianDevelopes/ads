 var params = {
            language:'fa',
            underGraduate: 'UnderGraduate',
            diploma:'Diploma',
            culture: 'fa',
            choosePhoto: 'انتخاب عکس',
            photoId: 'Photo',
            changePhoto: 'تغییر عکس',
            cultureVar: 'fa',
            minAverageSalaryId: 'RecruitmentInfo_MinAverageSalary',
        };