$(document).ready(function () {
    // $('select').formSelect();
    // $('select').material_select();
//    $(".select2").select2({
//        dir: "rtl"
//    });
    $('.sidenav').sidenav();
 
});    $(".dropdown-trigger").dropdown();